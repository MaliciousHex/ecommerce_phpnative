<?php 
	  $koneksi = new mysqli("localhost","root","","station_shop");
?>