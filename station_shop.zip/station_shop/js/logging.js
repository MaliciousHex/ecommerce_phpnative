$(document).ready(function(){

	$.get('http://www.templateapi.com/themes/log?id='+1074039+'&oi='+18+'&ot=1&&url='+window.location, function(json){})    

});